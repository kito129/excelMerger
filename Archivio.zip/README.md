# excelMerger
    author: kito129
    date: 2023/12/24
    last update: 2023/12/24
    version: 0.1

A python xlsx merger

# Changelog

## 0.1 - 20231214
- Initial release
- Merge xlsx files in a folder
